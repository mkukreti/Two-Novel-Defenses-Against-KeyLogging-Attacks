/*
 * Copyright (C) 2008-2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.softkeyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.util.Log;
import android.view.inputmethod.EditorInfo;

public class LatinKeyboard extends Keyboard {

    private Key mEnterKey;
    private Key mSpaceKey;
    private List<KeyData> backup;
    
    public LatinKeyboard(Context context, int xmlLayoutResId) {
        super(context, xmlLayoutResId);
    }

    public LatinKeyboard(Context context, int layoutTemplateResId, 
            CharSequence characters, int columns, int horizontalPadding) {
        super(context, layoutTemplateResId, characters, columns, horizontalPadding);
    }

    @Override
    protected Key createKeyFromXml(Resources res, Row parent, int x, int y, 
            XmlResourceParser parser) {
        Key key = new LatinKey(res, parent, x, y, parser);
        if (key.codes[0] == 10) {
            mEnterKey = key;
        } else if (key.codes[0] == ' ') {
            mSpaceKey = key;
        }
        return key;
    }
    
    /**
     * This looks at the ime options given by the current editor, to set the
     * appropriate label on the keyboard's enter key (if it has one).
     */
    void setImeOptions(Resources res, int options) {
        if (mEnterKey == null) {
            return;
        }
        
        switch (options&(EditorInfo.IME_MASK_ACTION|EditorInfo.IME_FLAG_NO_ENTER_ACTION)) {
            case EditorInfo.IME_ACTION_GO:
                mEnterKey.iconPreview = null;
                mEnterKey.icon = null;
                mEnterKey.label = res.getText(R.string.label_go_key);
                break;
            case EditorInfo.IME_ACTION_NEXT:
                mEnterKey.iconPreview = null;
                mEnterKey.icon = null;
                mEnterKey.label = res.getText(R.string.label_next_key);
                break;
            case EditorInfo.IME_ACTION_SEARCH:
                mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_search);
                mEnterKey.label = null;
                break;
            case EditorInfo.IME_ACTION_SEND:
                mEnterKey.iconPreview = null;
                mEnterKey.icon = null;
                mEnterKey.label = res.getText(R.string.label_send_key);
                break;
            default:
                mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_return);
                mEnterKey.label = null;
                break;
        }
    }

    void setSpaceIcon(final Drawable icon) {
        if (mSpaceKey != null) {
            mSpaceKey.icon = icon;
        }
    }

    static class LatinKey extends Keyboard.Key {
        protected int tempx, tempy, tempgap, tempedge;
        public LatinKey(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
            super(res, parent, x, y, parser);
            tempx = x;
            tempy = y;
            tempgap = gap;
            tempedge = edgeFlags;
        }
        
        /**
         * Overriding this method so that we can reduce the target area for the key that
         * closes the keyboard. 
         */
        @Override
        public boolean isInside(int x, int y) {
            return super.isInside(x, codes[0] == KEYCODE_CANCEL ? y - 10 : y);
        }
    }
    
    static class KeyData {
    	int x, y, gap, edgeFlags;
    	int code;
    }

    // Rearrange the keys
	public void rearrangeQwerty() {
		// TODO Auto-generated method stub
		Random random = new Random();
		int length = this.getKeys().size();
		for(int curKeyIndex = 0; curKeyIndex < this.getKeys().size(); curKeyIndex ++) {
			int code = this.getKeys().get(curKeyIndex).codes[0];
			if(code < 97 || code > 122) continue;
			int temp, attempt = 0;
			do {
				temp = random.nextInt(length - curKeyIndex) + curKeyIndex;
				code = this.getKeys().get(temp).codes[0];
			} while((code < 97 || code > 122) && attempt ++ < 10);
			if(code < 97 || code > 122) continue;
			switchKeys((LatinKey)this.getKeys().get(curKeyIndex), (LatinKey)this.getKeys().get(temp));
		}
	}
	
	public void rearrangeNumber() {
		Random random = new Random();
		int length = this.getKeys().size();
		for(int curKeyIndex = 0; curKeyIndex < this.getKeys().size(); curKeyIndex ++) {
			int code = this.getKeys().get(curKeyIndex).codes[0];
			if(code < 48 || code > 57) continue;
			int temp, attempt = 0;
			do {
				temp = random.nextInt(length - curKeyIndex) + curKeyIndex;
				code = this.getKeys().get(temp).codes[0];
			} while((code < 48 || code > 57) && attempt ++ < 10);
			if(code < 48 || code > 57) continue;
			switchKeys((LatinKey)this.getKeys().get(curKeyIndex), (LatinKey)this.getKeys().get(temp));
		}
	}

	private void switchKeys(LatinKey k1, LatinKey k2) {
		int temp = k1.codes[0];
		k1.codes[0] = k2.codes[0];
		k2.codes[0] = temp;
		CharSequence temp2 = k1.label;
		k1.label = k2.label;
		k2.label = temp2;
	}
}
